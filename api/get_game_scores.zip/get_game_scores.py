import json
import boto3
from decimal import Decimal

def decimal_default(obj):
    # DecimalをJSONで扱える型に変換
    if isinstance(obj, Decimal):
        return float(obj)  # 精度の問題を避けるためfloatに
    raise TypeError("非対応の型")

def get_dynamodb_table(table_name='GameScores'):
    # DynamoDBのテーブル名指定で取得
    dynamodb = boto3.resource('dynamodb')
    return dynamodb.Table(table_name)

def lambda_handler(event, context):
    table = get_dynamodb_table()  # テーブル取得
    
    # DynamoDBテーブル全スキャン
    response = table.scan()
    
    # scan結果をJSON形式でレスポンス
    # Decimal型はdecimal_defaultで変換
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'application/json'},
        'body': json.dumps(response['Items'], default=decimal_default)
    }